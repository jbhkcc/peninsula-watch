#!/usr/bin/env python3
"""Collect open-source data and create a clearly limited free preliminary risk screening.
No paid API. Alerts require corroboration in reputable RSS publisher *labels*.
No X real-time, confirmed embassy evacuation or foreign trading flows are claimed.
"""
import datetime as dt
import email.utils
import json
import os
import pathlib
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from assess_free import preliminary_assessment, with_previous

ROOT = pathlib.Path(__file__).resolve().parents[1]
UTC = dt.timezone.utc
NOW = dt.datetime.now(UTC)
ERRORS = []
HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; HWatchPublicMonitor/1.0; +https://github.com/)",
    "Accept": "application/json, application/rss+xml, application/xml;q=0.9, */*;q=0.8",
}


def fetch(url, timeout=16):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read()


def getjson(url):
    return json.loads(fetch(url).decode("utf-8"))


def iso_date(raw):
    if not raw:
        return None
    try:
        return email.utils.parsedate_to_datetime(raw).astimezone(UTC).isoformat(timespec="seconds")
    except (ValueError, TypeError):
        try:
            return dt.datetime.fromisoformat(raw.replace("Z", "+00:00")).astimezone(UTC).isoformat(timespec="seconds")
        except ValueError:
            return None


def rss(query, category):
    # US- and Japan-focused English queries; Google News is an aggregator.
    endpoint = "https://news.google.com/rss/search?" + urllib.parse.urlencode({
        "q": query,
        "hl": "en-US",
        "gl": "US",
        "ceid": "US:en",
    })
    raw = fetch(endpoint)
    root = ET.fromstring(raw)
    result = []
    for item in root.findall(".//channel/item")[:15]:
        title = (item.findtext("title") or "").strip()
        link = (item.findtext("link") or "").strip()
        if not title or not link.startswith("https://"):
            continue
        source_el = item.find("source")
        source = (source_el.text or "") if source_el is not None else "게시처 미상"
        result.append({
            "category": category,
            "title": title[:260],
            "url": link,
            "source": source[:80],
            "published_at": iso_date(item.findtext("pubDate")),
            "retrieved_via": "Google News RSS (기사 진위 미확인)",
        })
    return result


def collect_articles():
    categories = [
        ("military", "(North Korea OR South Korea) (military OR missile OR DMZ OR USFK) when:2d"),
        ("global", "(North Korea OR South Korea) (Reuters OR AP OR NHK OR Kyodo OR Bloomberg) when:2d"),
        ("embassy", '"South Korea" (embassy OR evacuation OR security alert OR travel advisory) when:7d'),
        ("market", '"South Korea" (foreign investors sell OR KOSPI OR KRW OR risk off) when:2d'),
    ]
    seen = set()
    articles = []
    ok = 0
    for category, query in categories:
        try:
            results = rss(query, category)
            ok += 1
            for a in results:
                # Only deduplicate within same displayed URL/title.
                key = (a["url"], a["title"].lower())
                if key not in seen:
                    articles.append(a)
                    seen.add(key)
        except (urllib.error.URLError, ValueError, ET.ParseError, TimeoutError) as exc:
            ERRORS.append({"source": f"Google News/{category}", "error": str(exc)[:180]})
    articles.sort(key=lambda x: x.get("published_at") or "", reverse=True)
    if ok == len(categories):
        state = "ok"
    elif ok > 0:
        state = "partial"
    else:
        state = "failed"
    return articles[:60], state


def collect_markets():
    markets = {}
    successes = 0
    attempted = 4

    try:
        upbit = getjson("https://api.upbit.com/v1/ticker?markets=KRW-BTC,KRW-ETH")
        for t in upbit:
            market = t.get("market")
            if market not in ("KRW-BTC", "KRW-ETH"):
                continue
            key = "btc" if market == "KRW-BTC" else "eth"
            price = t.get("trade_price")
            millis = t.get("timestamp")
            if price is not None:
                markets[key] = {
                    "value": float(price),
                    "change_percent": float(t.get("signed_change_rate", 0)) * 100,
                    "as_of": dt.datetime.fromtimestamp(int(millis) / 1000, UTC).isoformat(timespec="seconds") if millis else None,
                    "source": "Upbit public ticker (전일 종가 대비)",
                }
        if any(x in markets for x in ("btc", "eth")):
            successes += 1
    except (urllib.error.URLError, ValueError, TypeError, TimeoutError) as exc:
        ERRORS.append({"source": "Upbit", "error": str(exc)[:180]})

    try:
        fx = getjson("https://open.er-api.com/v6/latest/USD")
        rate = fx.get("rates", {}).get("KRW")
        if fx.get("result") == "success" and rate:
            markets["usdkrw"] = {
                "value": float(rate),
                "change_percent": None,
                "as_of": iso_date(fx.get("time_last_update_utc")),
                "source": "ExchangeRate-API free feed; 일일 참고환율, 실시간 호가 아님",
            }
            successes += 1
    except (urllib.error.URLError, ValueError, TypeError, TimeoutError) as exc:
        ERRORS.append({"source": "FX", "error": str(exc)[:180]})

    for symbol, key in (("%5EKS11", "kospi"), ("%5EKQ11", "kosdaq")):
        try:
            info = getjson(f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1d&range=5d")
            chart = info["chart"]["result"][0]
            meta = chart["meta"]
            price = meta.get("regularMarketPrice")
            prev = meta.get("previousClose") or meta.get("chartPreviousClose")
            time = meta.get("regularMarketTime")
            if price is None:
                raise ValueError("market price unavailable")
            markets[key] = {
                "value": float(price),
                "change_percent": (float(price) / float(prev) - 1) * 100 if prev else None,
                "as_of": dt.datetime.fromtimestamp(int(time), UTC).isoformat(timespec="seconds") if time else None,
                "source": "Yahoo Finance public chart (마지막 제공 지수값)",
            }
            successes += 1
        except (urllib.error.URLError, ValueError, KeyError, IndexError, TypeError, TimeoutError) as exc:
            ERRORS.append({"source": f"Yahoo/{key}", "error": str(exc)[:180]})

    return markets, "ok" if successes == attempted else ("partial" if successes else "failed")


def load_assessment():
    try:
        obj = json.loads((ROOT / "assessment.json").read_text(encoding="utf-8"))
        # It must be assigned by a person or a separate verified analysis process.
        if obj.get("stage") not in ("safe", "watch", "alert", "danger"):
            return None
        checked = obj.get("checked_at")
        if not iso_date(checked):
            ERRORS.append({"source": "assessment", "error": "A selected stage must have a valid checked_at timestamp"})
            return None
        summary = str(obj.get("summary") or "").strip()
        if not summary:
            ERRORS.append({"source": "assessment", "error": "Stage supplied without supporting summary"})
            return None
        return {
            "stage": obj["stage"],
            "checked_at": iso_date(checked),
            "summary": summary[:900],
            "source": str(obj.get("source") or "관리자 입력")[:90],
        }
    except (OSError, ValueError, TypeError) as exc:
        ERRORS.append({"source": "assessment", "error": str(exc)[:180]})
        return None



def previous_published_assessment():
    """Read prior *published* risk on GitHub Pages before overwriting extracted ZIP.
    GitHub Actions recreates `site/` from a ZIP on every run, so the ZIP itself
    cannot hold the previous hourly decision. A failed read => no invented trend.
    """
    repo = os.environ.get("GITHUB_REPOSITORY", "").strip()
    parts = repo.split("/")
    if len(parts) != 2 or not all(parts) or not all(p.replace("-", "").replace("_", "").isalnum() for p in parts):
        return None
    owner, project = parts
    base = ("https://" + owner + ".github.io/" + project +
            "/data/latest.json?v=" + str(int(NOW.timestamp())))
    try:
        old = getjson(base)
        if not isinstance(old, dict):
            return None
        if old.get("generated_at") and iso_date(old.get("generated_at")):
            # Ignore old published snapshots after a prolonged workflow outage.
            age = (NOW - dt.datetime.fromisoformat(iso_date(old["generated_at"]))).total_seconds()
            if age < 0 or age > 6 * 3600:
                return None
        else:
            return None
        return old.get("automatic_assessment") or old.get("assessment")
    except (urllib.error.URLError, TimeoutError, ValueError, TypeError, OSError):
        return None


def main():
    articles, news_status = collect_articles()
    markets, market_status = collect_markets()
    automatic = preliminary_assessment(articles, news_status, now=NOW)
    automatic = with_previous(automatic, previous_published_assessment(), now=NOW)
    # Preserve an administrator-entered, manually verified assessment if provided.
    # By default, the automatic preliminary evaluation is displayed.
    admin = load_assessment()
    record = {
        "generated_at": NOW.isoformat(timespec="seconds"),
        "collection_status": {"news": news_status, "markets": market_status},
        "assessment": admin or automatic,
        "automatic_assessment": automatic,
        "articles": articles,
        "markets": markets,
        "errors": ERRORS,
    }
    dest = ROOT / "data" / "latest.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {dest}: {len(articles)} articles; {len(markets)} market series; automated stage={automatic.get('stage') or 'unknown'} trend={automatic.get('change')}; {len(ERRORS)} collector errors")
    for err in ERRORS:
        print(f"  {err['source']}: {err['error']}")


if __name__ == "__main__":
    main()
