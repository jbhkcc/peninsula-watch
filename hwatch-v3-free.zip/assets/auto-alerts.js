/* H-WATCH V3 — On-page alerts while the PWA/page is open. No paid services or push server. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const LABEL = {safe:'안전',watch:'경계',alert:'경보',danger:'위험'};
  const RANK = {safe:0,watch:1,alert:2,danger:3};
  const store = (() => { try { return window.localStorage; } catch { return null; } })();
  const stamp = iso => { const d = new Date(iso); return !iso || isNaN(d) ? '자료 없음' : new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(d)+' KST'; };
  const isRecent = iso => { const t = Date.parse(iso||''); const age = Date.now()-t; return Number.isFinite(age) && age>=-60000 && age<2*3600*1000; };
  const trustedLink = url => { try { const u = new URL(url); return u.protocol==='https:'? u.href:null; } catch { return null; } };
  function setText(id, value) { const el=$(id); if(el) el.textContent=value; }

  async function notifySystem(stage, old) {
    if (!('Notification' in window) || Notification.permission !== 'granted' || !('serviceWorker' in navigator)) return;
    try {
      const reg = await navigator.serviceWorker.ready;
      await reg.showNotification('H-WATCH 예비 위험등급 상승', {
        body: `${LABEL[old]} → ${LABEL[stage]} · 공개 뉴스 제목 기반, 미검증 예비평가. 공식 공지를 확인하세요.`,
        tag: 'hwatch-risk-rise', renotify: false,
        icon: './assets/icon-192.png', badge: './assets/icon-192.png',
        data: {url: location.href}
      });
    } catch { /* some mobile browsers block this even with permission */ }
  }

  async function poll() {
    try {
      const res=await fetch(`data/latest.json?alert=${Date.now()}`,{cache:'no-store'});
      if (!res.ok) throw Error(`HTTP ${res.status}`);
      const data=await res.json();
      const a=data?.automatic_assessment || (data?.assessment?.method==='free_rules_v1'? data.assessment:null);
      if(!a) { setText('auto-notify-status','자동 예비평가 데이터가 없습니다.'); return; }
      const change = a.change==='up'?'▲ 상승':a.change==='down'?'▼ 하락':a.change==='same'?'변동 없음':'직전 비교 불가';
      const hasPrior = a.previous_stage in RANK;
      setText('auto-diff', hasPrior?`${LABEL[a.previous_stage]} → ${a.stage in RANK? LABEL[a.stage]:'판정 대기'} · ${change}`:change);
      setText('auto-confidence', a.stage in RANK ? (a.confidence||'낮음')+' · 예비판정' : '판정 보류');
      setText('auto-asof', stamp(a.checked_at));
      setText('auto-uncertainty', a.uncertainty || '기사 제목 기반 분석으로 군사상황을 확정할 수 없습니다.');
      const list=$('auto-evidence'); list.replaceChildren();
      if(Array.isArray(a.evidence) && a.evidence.length){
        for(const e of a.evidence.slice(0,5)){
          const li=document.createElement('li');const link=trustedLink(e.url);
          const child=document.createElement(link?'a':'div');
          if(link){child.href=link;child.target='_blank';child.rel='noopener noreferrer';}
          child.textContent=`${e.source||'보도 출처'} · ${e.title||'제목 없음'}`;
          const meta=document.createElement('small');meta.textContent=`게시 ${stamp(e.published_at)} · 제목 기반 참고 · 공식 검증 별도`;
          child.append(meta);li.append(child);list.append(li);
        }
      } else {const li=document.createElement('li');li.textContent='해당 평가를 뒷받침할 교차 출처 자료가 부족합니다.';list.append(li);}
      const rising = a.change==='up' && hasPrior && (a.stage in RANK) && RANK[a.stage]>RANK[a.previous_stage] && isRecent(a.checked_at);
      const banner=$('rise-banner');
      banner.classList.toggle('on',!!rising);
      if(rising){
        banner.replaceChildren();
        const first=document.createElement('div');first.textContent=`⚠ 자동 예비위험 등급 상승: ${LABEL[a.previous_stage]} → ${LABEL[a.stage]}`;
        const second=document.createElement('p');second.textContent=`${stamp(a.checked_at)} 공개 뉴스 제목 분석에서 감지. 원문·공식자료 검증 전이므로 정부 발표를 확인하세요.`;
        banner.append(first,second);
        // Only one system notification per freshly published rise per browser profile.
        const alertId=`${a.checked_at}|${a.previous_stage}|${a.stage}`;
        if(store?.getItem('hwatch-last-rise-v3') !== alertId){
          store?.setItem('hwatch-last-rise-v3', alertId);
          await notifySystem(a.stage,a.previous_stage);
        }
      }
    } catch(err) {
      setText('auto-diff','최신 자료 확인 실패');
      setText('auto-notify-status','자료 확인 실패: 네트워크 또는 배포 상태를 확인하세요.');
    }
  }

  async function enableNotification(){
    // In-page banner works without any OS permission.
    if (!('Notification' in window) || !('serviceWorker' in navigator)) {
      setText('auto-notify-status','이 브라우저는 시스템 알림을 지원하지 않습니다. 화면 알림만 작동합니다.');
      return;
    }
    if(Notification.permission === 'denied'){
      setText('auto-notify-status','알림이 차단돼 있습니다. iOS 설정에서 허용하거나 화면 알림만 이용하세요.'); return;
    }
    try {
      // Must be called directly from a user gesture on iOS.
      const result=await Notification.requestPermission();
      setText('auto-notify-status',result==='granted'?'시스템 알림 권한 허용됨 · 앱 실행 중 상승 시 표시 시도':
        result==='denied'?'알림 권한 거부됨 · 화면 경고는 유지':'시스템 알림은 활성화되지 않음 · 화면 경고 유지');
    } catch {
      setText('auto-notify-status','아이폰에서는 홈 화면에 추가해 웹 앱으로 실행해야 권한 요청이 가능할 수 있습니다.');
    }
  }

  function init(){
    $('enable-site-notify')?.addEventListener('click',enableNotification);
    if ('Notification' in window && Notification.permission==='granted') setText('auto-notify-status','시스템 알림 권한 허용됨 · 앱 실행 중 상승 시 표시 시도');
    poll(); setInterval(poll,5*60*1000);
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll();});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
