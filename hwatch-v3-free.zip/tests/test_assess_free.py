"""Run: python3 -m unittest discover -s tests -v. No Internet required."""
import datetime as dt
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1] / 'scripts'))
from assess_free import preliminary_assessment, with_previous


class FreeAssessmentTests(unittest.TestCase):
    NOW = dt.datetime(2026,11,3,12,0,tzinfo=dt.timezone.utc)

    def a(self, src, title, hrs=0):
        return {'source':src,'title':title,
                'published_at':(self.NOW-dt.timedelta(hours=hrs)).isoformat(),
                'url':f'https://news.google.com/rss/articles/{len(src)}{len(title)}'}

    def test_convergent_missile_headlines_watch(self):
        arr=[self.a('Reuters','North Korea fires two ballistic missiles'),
             self.a('AP News','North Korea fired multiple ballistic missiles today')]
        result=preliminary_assessment(arr,'ok',self.NOW)
        self.assertEqual(result['stage'],'watch')
        self.assertEqual(result['signal_type'],'missile')
        self.assertEqual(len(result['evidence']),2)

    def test_no_hypotheticals(self):
        arr=[self.a('Reuters','North Korea could fire missiles as tensions grow'),
             self.a('AP News','North Korea warns of missile launch in military exercises')]
        result=preliminary_assessment(arr,'ok',self.NOW)
        self.assertIsNone(result['stage'])

    def test_confident_sources_and_recent_only(self):
        arr=[self.a('Random Blog','North Korea invades South Korea'),
             self.a('Reuters','North Korea fires ballistic missile',35),
             self.a('AP News','North Korea fires ballistic missile',30)]
        self.assertIsNone(preliminary_assessment(arr,'ok',self.NOW)['stage'])

    def test_credible_nonsignal_can_be_safe_not_zero_risk(self):
        arr=[self.a('Reuters','South Korea and North Korea relations remain tense'),
             self.a('AP News','North Korea diplomacy news from this week'),
             self.a('NHK','South Korea defense officials hold bilateral talks')]
        result=preliminary_assessment(arr,'ok',self.NOW)
        self.assertEqual(result['stage'],'safe')
        self.assertIn('전쟁 위험이 없다는 판단이 아닙니다',result['summary'])

    def test_border_clash_alert(self):
        arr=[self.a('Reuters','North Korea launches artillery shelling near the border'),
             self.a('AP News','North Korea launched artillery attack near border')]
        self.assertEqual(preliminary_assessment(arr,'ok',self.NOW)['stage'],'alert')

    def test_invasion_danger_three_independent_publishers(self):
        arr=[self.a('Reuters','North Korea invades South Korea'),
             self.a('AP News','North Korea invades South Korea'),
             self.a('NHK','North Korea invades South Korea')]
        self.assertEqual(preliminary_assessment(arr,'ok',self.NOW)['stage'],'danger')

    def test_single_publisher_not_corrobated(self):
        arr=[self.a('Reuters','North Korea fires two ballistic missiles'),
             self.a('Reuters','North Korea fired multiple ballistic missiles today')]
        self.assertIsNone(preliminary_assessment(arr,'ok',self.NOW)['stage'])

    def test_publication_clustering(self):
        arr=[self.a('Reuters','North Korea fired two ballistic missiles',1),
             self.a('AP News','North Korea launches ballistic missiles',22)]
        self.assertIsNone(preliminary_assessment(arr,'ok',self.NOW)['stage'])

    def test_increasing_level_trend(self):
        arr=[self.a('Reuters','North Korea fires two ballistic missiles'),
             self.a('AP News','North Korea fired multiple ballistic missiles today')]
        curr=preliminary_assessment(arr,'ok',self.NOW)
        prev={'stage':'safe','method':'free_rules_v1',
              'checked_at':(self.NOW-dt.timedelta(hours=1)).isoformat()}
        self.assertEqual(with_previous(curr,prev,self.NOW)['change'],'up')

    def test_no_false_rise_on_unknown_previous(self):
        a={'stage':'watch','method':'free_rules_v1','checked_at':self.NOW.isoformat()}
        a['change']='unknown'
        self.assertEqual(with_previous(a,{'stage':None},self.NOW)['change'],'unknown')


if __name__=='__main__':unittest.main()
