const CACHE='hwatch-ui-v4';
const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/icon.svg','./assets/icon-192.png','./assets/auto-alerts.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(x=>x!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==location.origin||e.request.method!=='GET')return;
 if(u.pathname.endsWith('/data/latest.json')){e.respondWith(fetch(e.request,{cache:'no-store'}).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put('./data/latest.json',copy));return r}).catch(()=>new Response(JSON.stringify({error:'network unavailable'}),{status:503,headers:{'Content-Type':'application/json'}})));return;}
 e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
});

self.addEventListener('notificationclick',event => {
  event.notification.close();
  event.waitUntil((async () => {
    const clientsOpen=await clients.matchAll({type:'window',includeUncontrolled:true});
    if(clientsOpen.length){ await clientsOpen[0].focus(); return; }
    await clients.openWindow('./');
  })());
});
