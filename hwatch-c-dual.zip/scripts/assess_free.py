#!/usr/bin/env python3
"""Conservative zero-API-key *headline-based preliminary signal screening*.

NEVER represent these heuristics as an independently verified war forecast.
Source identity, event times, claims, false positives remain uncertain.
Markets/X are deliberately excluded from escalation rules.
"""
import datetime as dt
import re
from collections import defaultdict
from urllib.parse import urlparse

UTC = dt.timezone.utc
RANK = {"safe": 0, "watch": 1, "alert": 2, "danger": 3}

# Only publisher labels supplied by Google News RSS, not a verified publisher signature.
PUBLISHERS = {
    "reuters": "Reuters", "associated press": "AP", "ap news": "AP", "nhk": "NHK",
    "nhk world": "NHK", "kyodo news": "Kyodo", "kyodo": "Kyodo",
    "bloomberg": "Bloomberg", "bbc": "BBC", "financial times": "FT",
    "the guardian": "The Guardian", "wall street journal": "WSJ", "the wall street journal": "WSJ",
    "nikkei asia": "Nikkei", "the japan times": "Japan Times", "cnn": "CNN",
    "afp": "AFP", "france 24": "France24", "dw": "DW",
    "yonhap news agency": "Yonhap", "yonhap": "Yonhap",
}

# Titles containing speculation, denial, commentary, historical incidents, or exercises
# must NOT produce a military action signal.
NON_EVENTS = re.compile(
    r"\b(?:could|might|may|would|if|plans? to|threatens?|warns?|warning|"
    r"fears?|scenario|simulation|war game|war games|wargam(?:e|ing)|"
    r"drills?|exercises?|training|rehearsals?|hypothetical|predicts?|"
    r"possible|possibility|potential|would-be|prepares? for|vows? to|"
    r"denies|denied|false|fake|debunks?|fact.check|rumou?rs?|"
    r"anniversary|years? ago|history|historical|opinion|explainer|"
    r"no evidence|no indication|not launched|did not launch|"
    r"mock|simulated|simulation|proposals?|urges?|calls? for)\b",
    re.I,
)
NK_CONTEXT = re.compile(r"\b(?:north korea|north korean|dprk|pyongyang|kim jong.un)\b", re.I)
KOREA_CONTEXT = re.compile(r"\b(?:south korea|south korean|seoul|korean peninsula|usfk)\b", re.I)
KEYWORDS = {
    "missile": re.compile(r"\b(?:missile[s]?|ballistic|icbm|rocket[s]?)\b.{0,90}\b(?:fir(?:e|ed|es|ing)|launch(?:ed|es)?|test(?:ed|s)?|detonat\w*)\b|\b(?:fir(?:e|ed|es|ing)|launch(?:ed|es)?|test(?:ed|s)?)\b.{0,90}\b(?:missile[s]?|ballistic|icbm|rocket[s]?)\b", re.I),
    "nuclear": re.compile(r"\b(?:nuclear (?:test|explosion|detonation)|atomic (?:test|explosion))\b.{0,90}\b(?:conducted|detonated|tested|carried out|performed)\b|\b(?:conducted|detonated|tested|carried out|performed)\b.{0,90}\b(?:nuclear (?:test|explosion|detonation)|atomic (?:test|explosion))\b", re.I),
    "clash": re.compile(r"\b(?:exchange[d]? (?:of )?(?:gunfire|fire)|artillery (?:strike[s]?|shelling|attack[s]?)|shell(?:ed|ing) (?:south korea|island|border|seoul)|border (?:clash|shootout|skirmish)|soldiers? killed (?:at|near) (?:the )?border|cross.border (?:attack|fire|shooting))\b", re.I),
    "invasion": re.compile(r"\b(?:north korea(?:n)? (?:invades?|invaded|launches? (?:an? )?(?:full.scale )?(?:invasion|attack) (?:on|against) south korea)|full.scale (?:invasion|war) (?:begins|underway)|war (?:breaks out|has begun) (?:between|on) (?:north and south )?korea|north korean troops (?:invade|cross(?:ed)? into) south korea)\b", re.I),
    "embassy": re.compile(r"\b(?:embass(?:y|ies)|diplomats?|nonessential (?:staff|personnel)|military families|dependents)\b.{0,100}\b(?:evacuat(?:e|ed|ion)|ordered (?:to )?leave|withdraw(?:n)?|depart(?:ure)?|ordered home)\b|\b(?:evacuat(?:e|ed|ion)|ordered (?:to )?leave|withdraw(?:n)?|depart(?:ure)?)\b.{0,90}\b(?:embass(?:y|ies)|diplomats?|staff|families)\b", re.I),
}


def publisher_name(source):
    s = re.sub(r"\s+", " ", str(source or "").strip().lower())
    return PUBLISHERS.get(s)


def parse_utc(s):
    try:
        d = dt.datetime.fromisoformat(str(s).replace("Z", "+00:00"))
        return d.astimezone(UTC) if d.tzinfo else None
    except (TypeError, ValueError):
        return None


def examine_title(item):
    title = re.sub(r"\s+", " ", str(item.get("title") or "").strip())
    if not title or NON_EVENTS.search(title):
        return None
    # Only regional items: source query alone is insufficient evidence.
    if not (NK_CONTEXT.search(title) or KOREA_CONTEXT.search(title)):
        return None
    if KEYWORDS["invasion"].search(title) and NK_CONTEXT.search(title) and KOREA_CONTEXT.search(title):
        return "invasion"
    if KEYWORDS["clash"].search(title) and NK_CONTEXT.search(title):
        return "clash"
    if KEYWORDS["nuclear"].search(title) and NK_CONTEXT.search(title):
        return "nuclear"
    if KEYWORDS["missile"].search(title) and NK_CONTEXT.search(title):
        return "missile"
    if KEYWORDS["embassy"].search(title) and KOREA_CONTEXT.search(title):
        return "embassy"
    return None


def preliminary_assessment(articles, news_status, now=None):
    """Return assessment for the *published headlines only*; can be unknown."""
    now = now or dt.datetime.now(UTC)
    now = now.astimezone(UTC)
    usable = []
    events = defaultdict(list)
    # RSS source names are not digital signatures; avoid overconfidence.
    for a in articles:
        pub = publisher_name(a.get("source"))
        when = parse_utc(a.get("published_at"))
        if not pub or not when or not 0 <= (now - when).total_seconds() <= 24 * 3600:
            continue
        url = str(a.get("url") or "")
        if not url.startswith("https://") or not urlparse(url).hostname:
            continue
        title = str(a.get("title") or "")
        usable.append((pub, a))
        signal = examine_title(a)
        if signal:
            events[signal].append((pub, a))

    # Multiple Google News entries for the same outlet do not independently corroborate an event.
    distinct = {pub for pub, _ in usable}
    reliable = {"Reuters", "AP", "NHK", "Kyodo", "BBC", "Bloomberg", "FT", "AFP", "Yonhap"}
    foreign = distinct - {"Yonhap"}
    stage = None
    selected = []
    kind = None
    evidence_note = ""

    # Highest priority first. Each event category independently requires distinct sources.
    for candidate, threshold, level in [
        ("invasion", 3, "danger"),
        ("clash", 2, "alert"),
        ("nuclear", 2, "watch"),
        ("embassy", 2, "watch"),
        ("missile", 2, "watch"),
    ]:
        items = events[candidate]
        # Require publication clustering, otherwise multiple separate incidents
        # from 24 hours must not be misread as one independently verified event.
        clusters = []
        for pub, article in sorted(items, key=lambda x: x[1].get("published_at") or ""):
            published = parse_utc(article.get("published_at"))
            cluster = [(p, a) for p, a in items
                       if (t := parse_utc(a.get("published_at")))
                       and abs((published - t).total_seconds()) <= 6*3600]
            clusters.append(cluster)
        best = max(clusters, key=lambda x: len({p for p, _ in x}), default=[])
        reporters = {pub for pub, _ in best}
        # At least one major independent publisher must be present.
        if len(reporters) >= threshold and (reporters & reliable):
            stage, kind, selected = level, candidate, best
            break

    if stage is None and news_status != "failed" and len(distinct) >= 3 and len(foreign) >= 2:
        stage = "safe"
        evidence_note = "확인한 최근 해외 주요매체의 제목 범위에서 상향 규칙에 해당하는 복수 보도가 없었습니다. 위협 부재를 뜻하지 않습니다."
        # Show examples to justify that the screening had sources.
        selected = usable[:3]
    elif stage is None:
        evidence_note = "최근 24시간 내 교차확인 가능한 주요매체 제목이 부족하거나, 동일 사건에 대한 독립 보도가 부족합니다."

    labels = {"missile": "미사일 발사·시험 보도", "nuclear": "핵실험 관련 보도", "embassy": "주한 외교공관 인력 이동 관련 보도", "clash": "국경 무력충돌 관련 보도", "invasion": "침공·전면전 개시 관련 보도"}
    short = labels.get(kind, "제한적 공개자료 확인")
    if stage in ("danger", "alert", "watch"):
        notes = sorted({p for p, _ in selected})
        summary = f"{short}가 {len(notes)}개 매체의 제목에서 포착됐습니다({', '.join(notes[:5])}). 이는 원문·공식 군 발표 확인 이전의 자동 예비평가이며 전쟁 임박 확정판정이 아닙니다."
    elif stage == "safe":
        summary = "확인된 주요매체 제목 범위에서 더 높은 단계로 분류할 교차 출처 신호가 부족합니다. 이는 전쟁 위험이 없다는 판단이 아닙니다."
    else:
        summary = "공개 뉴스 제목만으로 신뢰할 만한 위험 등급을 정할 수 없어 판정을 보류했습니다. 정보 부재는 위험 부재가 아닙니다."

    evidence = []
    used = set()
    # distinct publisher citation with provenance and publication timestamp
    for pub, item in selected:
        if pub in used:
            continue
        used.add(pub)
        evidence.append({
            "source": pub, "title": str(item.get("title") or "")[:260],
            "url": str(item.get("url") or ""),
            "published_at": item.get("published_at"),
            "note": "Google News RSS에서 수집된 제목 — 원문·사건 진위 미확인",
        })
        if len(evidence) >= 5:
            break

    confidence = "낮음"  # source headlines only, not primary verification
    return {
        "stage": stage,
        "checked_at": now.isoformat(timespec="seconds"),
        "summary": summary,
        "source": "무료 자동 예비평가 · 주요 외신 제목 규칙 (비공식)",
        "method": "free_rules_v1",
        "confidence": confidence,
        "evidence": evidence,
        "signal_type": kind,
        "uncertainty": (evidence_note + " " if evidence_note else "") +
            "기사는 제목만 자동 확인했으며 원문, 공식 군 발표, 사건 발생 시각, 대사관 실제 철수, X 게시물, 외국인 순매도는 검증하지 못했습니다. 시장 가격 변동은 위험 단계 판정에 사용하지 않습니다.",
        "previous_stage": None,
        "change": "unknown",
        "previous_checked_at": None,
    }


def with_previous(current, previous, now=None):
    """Compare only to a recent analysis produced by *same* screening method."""
    now = now or dt.datetime.now(UTC)
    current = dict(current)
    if not isinstance(previous, dict) or previous.get("method") != "free_rules_v1":
        return current
    last_time = parse_utc(previous.get("checked_at"))
    if not last_time or not 0 <= (now - last_time).total_seconds() < 6*3600:
        return current
    a, b = previous.get("stage"), current.get("stage")
    if a not in RANK or b not in RANK:
        return current
    current["previous_stage"] = a
    current["previous_checked_at"] = previous.get("checked_at")
    current["change"] = "up" if RANK[b] > RANK[a] else "down" if RANK[b] < RANK[a] else "same"
    return current


# Separate early-warning *headline signal* from confirmed official assessment.
def early_warning_assessment(articles, news_status, now=None):
    now = (now or dt.datetime.now(UTC)).astimezone(UTC)
    base = preliminary_assessment(articles, news_status, now)
    candidates = []
    for item in articles:
        when = parse_utc(item.get('published_at'))
        if not when or not 0 <= (now-when).total_seconds() <= 24*3600:
            continue
        if not publisher_name(item.get('source')):
            continue
        signal = examine_title(item)
        if signal:
            candidates.append((signal,item))
    # Single reputable headline is enough for an *unverified signal*, not a verified event.
    if base['stage'] is None and not candidates:
        return {**base, 'method':'early_headlines_v1', 'source':'조기경보 · 주요매체 제목 감시 (비공식)',
                'summary':'최근 제목 자료가 부족해 조기경보 신호도 판단할 수 없습니다.'}
    order = {'missile':1,'nuclear':1,'embassy':1,'clash':2,'invasion':3}
    strongest = max((order[x[0]] for x in candidates),default=0)
    if base['stage'] in RANK:
        strongest = max(strongest,RANK[base['stage']])
    stage = ('safe','watch','alert','danger')[strongest]
    evidence=[]; used=set()
    for signal,item in sorted(candidates,key=lambda x:order[x[0]],reverse=True):
        pub=publisher_name(item.get('source'))
        if pub in used:continue
        used.add(pub)
        evidence.append({'source':pub,'title':item.get('title'),'url':item.get('url'),
                         'published_at':item.get('published_at'), 'note':'기사 제목 신호, 원문·사건 미검증'})
        if len(evidence)>=5:break
    return {**base, 'stage':stage, 'method':'early_headlines_v1',
            'source':'조기경보 · 주요매체 제목 감시 (비공식)',
            'confidence':'낮음', 'signal_type':candidates[0][0] if candidates else None,
            'evidence':evidence or base['evidence'],
            'summary':('최근 주요매체 제목에서 위험 신호가 감지됐습니다. 이는 사건 확인이나 전쟁 발생 확률이 아닙니다.' if strongest else '수집된 제목 범위에서 규칙에 맞는 조기경보 신호가 포착되지 않았습니다. 안전이 확인된 것은 아닙니다.'),
            'uncertainty':'원문, 사건 발생 시각, 공식 군 발표를 검증하지 않았습니다. 서로 다른 기사가 같은 사건일 수 있습니다. 미수집은 안전을 의미하지 않습니다.'}
